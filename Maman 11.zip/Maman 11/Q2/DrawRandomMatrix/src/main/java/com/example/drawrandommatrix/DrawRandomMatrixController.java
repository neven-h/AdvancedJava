package com.example.drawrandommatrix;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.Random;

import static java.lang.Math.floor;

// create randomly filled matrix
public class DrawRandomMatrixController {

    @FXML
    private Canvas canvas; // used to get the GraphicsContext


    @FXML
    void drawMatrixButtonPressed(ActionEvent event) {
        drawRandomMatrix();
    }

    // draw matrix in canvas and fill 10 percent of elements
    private void drawRandomMatrix() {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        // clear canvas for next set of matrix elements
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        final int MATRIX_SCALE = 10; // 10 pixels spaces between each line in matrix
        int rows = (int) floor(canvas.getHeight() / MATRIX_SCALE); // rows possible to create in canvas
        int cols = (int) floor(canvas.getWidth() / MATRIX_SCALE); // columns possible to create in canvas
        int x; // x parameter of (x,y) coordinate in matrix
        int y; // y parameter of (x,y) coordinate in matrix

        int[][] matrix = new int[rows][cols]; // create 2D array with 0's
        fillRandom(matrix); // randomly fill 10 percent of 2D array with 1's

        // draw matrix on canvas
        for (int col = 0; col < cols; col++) {
            for (int row = 0; row < rows; row++) {
                // Scaling up to draw a rectangle at (x,y) coordinate
                x = col * MATRIX_SCALE;
                y = row * MATRIX_SCALE;

                // for every column and row, a rectangle is drawn at an (x,y) location and sized by matrix scale
                // fill rectangle represent a 1 value in array
                if (matrix[row][col] == 1) {
                    gc.setFill(Color.BLACK);
                    gc.fillRect(x, y, MATRIX_SCALE, MATRIX_SCALE);
                }

                //stroke rectangle represent 0 value in array
                if (matrix[row][col] == 0) {
                    gc.setFill(Color.BLACK);
                    gc.strokeRect(x, y, MATRIX_SCALE, MATRIX_SCALE);
                }
            }
        }
    }

    // randomly fills 10 percents of elements with 1's and the rest with 0's
    private void fillRandom(int[][] matrix) {
        int matrixRows = matrix.length;
        int matrixColumns = matrix[0].length;
        int row;
        int col;
        int tenPercent = (int) floor(matrixRows * matrixColumns * 0.1); // 10 percent of matrix elements
        int count = 0; // count number of rectangle already filled in matrix

        Random rand = new Random();

        // randomly fill ten percent of elements of matrix
        while (count < tenPercent) {
            // randomly choose element in matrix
            row = rand.nextInt(matrixRows);
            col = rand.nextInt(matrixColumns);

            // set value of element to 1 if current value in element is 0
            if (matrix[row][col] != 1) {
                matrix[row][col] = 1;
                count++;
            }
        }
    }
}