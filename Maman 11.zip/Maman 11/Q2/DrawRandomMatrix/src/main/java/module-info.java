module com.example.drawrandommatrix {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.drawrandommatrix to javafx.fxml;
    exports com.example.drawrandommatrix;
}